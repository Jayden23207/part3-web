/* =========================================================
   script.js — Uber student site (Part 3: JavaScript)
   Shared by every page. Each feature only runs if the
   elements it needs exist on the current page.
   ========================================================= */
(function () {
  'use strict';

  /* ---------- Helpers ---------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const page = (location.pathname.split('/').pop() || 'index.html').replace('.html', '') || 'index';
  const money = (n) => 'R' + n.toFixed(2);

  // Build elements with textContent only (never innerHTML) so user input can't inject markup.
  function el(tag, attrs = {}, ...kids) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v);
    }
    kids.forEach((kid) => node.append(kid));
    return node;
  }

  /* ---------- Data (arrays used to build the pages) ---------- */
  const SERVICES = [
    { name: 'Ride', text: 'Get a car when you need one', href: 'ride.html' },
    { name: 'Deliver', text: 'Order food or work as a driver', href: 'deliver.html' },
    { name: 'Business', text: 'Manage travel for your company', href: 'business.html' }
  ];

  // Illustrative rates only (not real Uber pricing)
  const RIDES = [
    { name: 'UberX', text: 'a normal, low cost ride', seats: 4, base: 10, perKm: 7 },
    { name: 'Comfort', text: 'a bigger car with more space', seats: 4, base: 15, perKm: 9 },
    { name: 'UberXL', text: 'a ride for up to 6 people', seats: 6, base: 20, perKm: 12 }
  ];

  const PLACES = [
    { name: 'Burger Bay', food: 'Burgers, fries', cat: 'Meals', eta: '20–30 min' },
    { name: 'Pasta Corner', food: 'Pasta, pizza', cat: 'Meals', eta: '25–35 min' },
    { name: 'Spice Route', food: 'Curry, rice, naan', cat: 'Meals', eta: '30–40 min' },
    { name: 'Sushi Stop', food: 'Sushi, noodles', cat: 'Meals', eta: '25–35 min' },
    { name: 'Fresh Basket', food: 'Fruit, vegetables, dairy', cat: 'Groceries', eta: '35–45 min' },
    { name: 'Corner Pantry', food: 'Bread, milk, snacks', cat: 'Groceries', eta: '20–30 min' },
    { name: 'Pharma Plus', food: 'Health and personal care', cat: 'Other items', eta: '30–40 min' },
    { name: 'Gift Box', food: 'Cards, flowers, small gifts', cat: 'Other items', eta: '40–50 min' }
  ];

  const JOBS = [
    { title: 'Front End Developer', place: 'Remote' },
    { title: 'UX Researcher', place: 'San Francisco' },
    { title: 'Business Manager', place: 'London' },
    { title: 'Driver Support Agent', place: 'Johannesburg' },
    { title: 'Data Analyst', place: 'Sydney' }
  ];

  const NEWS = [
    { title: 'Uber shares its newest results', tag: 'Results' },
    { title: 'Uber adds service in new cities', tag: 'Expansion' },
    { title: 'Uber launches new safety tools', tag: 'Safety' }
  ];

  const FAQS = [
    { q: 'How do I cancel a ride?', a: 'Open your trip and tap cancel before the driver arrives.' },
    { q: 'How do I get money back for an order?', a: 'Go to your order and tap "Report a problem."' },
    { q: 'How do I change my payment card?', a: 'Go to your account settings and update your card.' },
    { q: 'How do I share my trip with a friend?', a: 'During your trip, open the safety menu and choose share trip status.' },
    { q: 'How do I become a driver?', a: 'Fill in the form on the driver page and upload your driver\'s licence.' },
    { q: 'How do I set up a business account?', a: 'Go to the business page and send a demo request with your work email.' }
  ];

  const GALLERY = [
    { src: 'IMAGES/download (1).jpg', alt: 'Dark Uber car on a city street', cap: 'Uber on the street' },
    { src: 'IMAGES/download (2).jpg', alt: 'Hand holding a phone with the Uber app next to a moving car', cap: 'Request a ride in the app' },
    { src: 'IMAGES/download.jpg', alt: 'Silver car with an Uber logo on the door', cap: 'Uber vehicle' },
    { src: 'IMAGES/images (1).jpg', alt: 'Phone with the Uber logo lying on a road map next to a toy car', cap: 'Plan your route' },
    { src: 'IMAGES/images (2).jpg', alt: 'Passenger talking to the driver in the back seat of a car', cap: 'A passenger gets in' },
    { src: 'IMAGES/images (3).jpg', alt: 'Phone with the Uber logo in front of a taxi sign', cap: 'Uber and taxis' },
    { src: 'IMAGES/images (4).jpg', alt: 'Uber Eats courier carrying a green delivery bag', cap: 'Uber Eats delivery' },
    { src: 'IMAGES/images (6).jpg', alt: 'Driver with a hand on the steering wheel', cap: 'Driving with Uber' },
    { src: 'IMAGES/images (7).jpg', alt: 'Finger tapping a map on a phone showing the Uber logo', cap: 'Choose a pickup point' }
  ];

  // Map markers: city centres only (no street addresses)
  const OFFICES = [
    { country: 'United States', city: 'San Francisco', lat: 37.7749, lon: -122.4194, cur: 'US dollar (USD)' },
    { country: 'United Kingdom', city: 'London', lat: 51.5074, lon: -0.1278, cur: 'British pound (GBP)' },
    { country: 'South Africa', city: 'Johannesburg', lat: -26.2041, lon: 28.0473, cur: 'South African rand (ZAR)' },
    { country: 'Australia', city: 'Sydney', lat: -33.8688, lon: 151.2093, cur: 'Australian dollar (AUD)' }
  ];

  /* ---------- Modal (native <dialog>) ---------- */
  let modal;
  function getModal() {
    if (modal) return modal;
    modal = el('dialog', { class: 'modal', 'aria-labelledby': 'modal-title' });
    document.body.append(modal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeDialog(modal); });
    return modal;
  }
  function closeDialog(d) { d.close ? d.close() : d.removeAttribute('open'); }
  function openDialog(d) { d.showModal ? d.showModal() : d.setAttribute('open', ''); }

  function showModal(title, ...bodyNodes) {
    const m = getModal();
    const close = el('button', { class: 'btn', type: 'button', text: 'Close' });
    close.addEventListener('click', () => closeDialog(m));
    m.replaceChildren(el('h2', { id: 'modal-title', text: title }), ...bodyNodes, el('div', { class: 'btn-row' }, close));
    openDialog(m);
    close.focus();
  }

  /* ---------- 1. Mobile navigation ---------- */
  const toggle = $('.nav-toggle');
  const nav = $('.site-nav');
  if (toggle && nav) {
    const setOpen = (open) => {
      nav.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', String(open));
    };
    toggle.addEventListener('click', () => setOpen(!nav.classList.contains('open')));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
    window.addEventListener('resize', () => { if (window.innerWidth > 768) setOpen(false); });
  }

  /* ---------- 2. Rendering from arrays (DOM manipulation) ---------- */
  const services = $('#services');
  if (services) {
    services.replaceChildren(...SERVICES.map((s) =>
      el('div', { class: 'card' }, el('b', { text: s.name }), s.text, el('br'), el('a', { href: s.href, text: 'Learn more' }))));
  }

  const rideBox = $('#ride-options');
  if (rideBox) {
    rideBox.replaceChildren(...RIDES.map((r) =>
      el('div', { class: 'card' }, el('b', { text: r.name }),
        el('span', { text: `${r.text} · up to ${r.seats} seats · from ${money(r.base)}` }))));
  }

  // Generic live filter: shows only items whose text contains the query
  function liveFilter(input, items, getText, render, countEl, noun) {
    const run = () => {
      const q = input.value.trim().toLowerCase();
      const hits = items.filter((it) => getText(it).toLowerCase().includes(q));
      render(hits);
      if (countEl) countEl.textContent = hits.length ? `${hits.length} ${noun}${hits.length === 1 ? '' : 's'} shown` : `No ${noun}s match "${input.value.trim()}".`;
    };
    input.addEventListener('input', run);
    run();
    return run;
  }

  // Deliver: places list with search + category chips
  const placesBox = $('#places');
  if (placesBox) {
    let cat = 'All';
    const search = $('#place-search');
    const chipBox = $('#place-filters');
    const draw = (list) => placesBox.replaceChildren(...list.map((p) =>
      el('div', { class: 'card' }, el('b', { text: p.name }), el('span', { text: `${p.food} · ${p.eta}` }))));
    const run = liveFilter(search, PLACES, (p) => `${p.name} ${p.food} ${p.cat}`, (list) => draw(list.filter((p) => cat === 'All' || p.cat === cat)), $('#places-count'), 'place');
    ['All', 'Meals', 'Groceries', 'Other items'].forEach((c) => {
      const chip = el('button', { type: 'button', class: 'chip' + (c === 'All' ? ' active' : ''), 'aria-pressed': String(c === 'All'), text: c });
      chip.addEventListener('click', () => {
        cat = c;
        $$('.chip', chipBox).forEach((b) => { b.classList.toggle('active', b === chip); b.setAttribute('aria-pressed', String(b === chip)); });
        run();
        const shown = $$('.card', placesBox).length;
        $('#places-count').textContent = shown ? `${shown} place${shown === 1 ? '' : 's'} shown` : 'No places match.';
      });
      chipBox.append(chip);
    });
  }

  // Careers: jobs list with live search
  const jobsBox = $('#jobs');
  if (jobsBox) {
    liveFilter($('#job-search'), JOBS, (j) => `${j.title} ${j.place}`,
      (list) => jobsBox.replaceChildren(...list.map((j) => el('div', { class: 'card' }, el('b', { text: j.title }), el('span', { text: j.place })))),
      $('#jobs-count'), 'job');
  }

  // Newsroom: stories with live search; links open a modal instead of jumping to "#"
  const newsBox = $('#news');
  if (newsBox) {
    liveFilter($('#news-search'), NEWS, (n) => `${n.title} ${n.tag}`,
      (list) => newsBox.replaceChildren(...list.map((n) => {
        const a = el('a', { href: '#', text: n.title });
        a.addEventListener('click', (e) => {
          e.preventDefault();
          showModal(n.title, el('p', { text: `Category: ${n.tag}.` }), el('p', { text: 'The full story is not part of this student project.' }));
        });
        return el('li', {}, a, el('span', { class: 'tag', text: n.tag }));
      })),
      $('#news-count'), 'story');
  }

  /* ---------- 3. Interactive elements ---------- */

  // 3a. FAQ accordion + live help search
  const faqBox = $('#faq');
  if (faqBox) {
    const draw = (list) => {
      faqBox.replaceChildren(...list.map((f, i) => {
        const btn = el('button', { type: 'button', class: 'acc-btn', 'aria-expanded': 'false', 'aria-controls': `faq-p${i}`, id: `faq-b${i}`, text: f.q });
        const panel = el('div', { class: 'acc-panel', id: `faq-p${i}`, role: 'region', 'aria-labelledby': `faq-b${i}`, hidden: '' }, el('p', { text: f.a }));
        btn.addEventListener('click', () => {
          const open = btn.getAttribute('aria-expanded') === 'true';
          btn.setAttribute('aria-expanded', String(!open));
          panel.hidden = open;
        });
        return el('div', { class: 'acc-item' }, el('h4', {}, btn), panel);
      }));
    };
    const input = $('#faq-search');
    liveFilter(input, FAQS, (f) => `${f.q} ${f.a}`, draw, $('#faq-count'), 'answer');
    const searchBtn = $('.search-bar input[type="submit"]');
    if (searchBtn) searchBtn.addEventListener('click', (e) => { e.preventDefault(); input.focus(); });
  }

  // 3b. Image gallery with lightbox
  const gallery = $('#gallery');
  if (gallery) {
    const box = el('dialog', { class: 'lightbox', 'aria-label': 'Image viewer' });
    const img = el('img', { alt: '' });
    const cap = el('p', { class: 'lb-cap' });
    const prev = el('button', { type: 'button', class: 'lb-btn', 'aria-label': 'Previous image', text: '‹' });
    const next = el('button', { type: 'button', class: 'lb-btn', 'aria-label': 'Next image', text: '›' });
    const shut = el('button', { type: 'button', class: 'lb-close', 'aria-label': 'Close viewer', text: '×' });
    box.append(shut, el('div', { class: 'lb-row' }, prev, img, next), cap);
    document.body.append(box);
    let cur = 0;
    const show = (i) => {
      cur = (i + GALLERY.length) % GALLERY.length;
      img.src = GALLERY[cur].src; img.alt = GALLERY[cur].alt;
      cap.textContent = `${GALLERY[cur].cap} (${cur + 1} of ${GALLERY.length})`;
    };
    GALLERY.forEach((g, i) => {
      const thumb = el('img', { src: g.src, alt: g.alt, loading: 'lazy' });
      const b = el('button', { type: 'button', class: 'thumb', 'aria-label': `Enlarge: ${g.cap}` }, thumb);
      b.addEventListener('click', () => { show(i); openDialog(box); shut.focus(); });
      gallery.append(b);
    });
    prev.addEventListener('click', () => show(cur - 1));
    next.addEventListener('click', () => show(cur + 1));
    shut.addEventListener('click', () => closeDialog(box));
    box.addEventListener('click', (e) => { if (e.target === box) closeDialog(box); });
    box.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') show(cur - 1);
      if (e.key === 'ArrowRight') show(cur + 1);
    });
  }

  // 3c. Interactive map (OpenStreetMap embed) + region selector
  const mapBox = $('#map');
  if (mapBox) {
    const select = $('#region');
    const info = $('#region-info');
    const frame = el('iframe', { title: 'Map of the selected region', loading: 'lazy' });
    const link = el('a', { target: '_blank', rel: 'noopener', text: 'Open a larger map' });
    const btnRow = el('div', { class: 'chips' });
    mapBox.append(btnRow, frame, el('p', { class: 'map-link' }, link));
    const go = (country) => {
      const o = OFFICES.find((x) => x.country === country) || OFFICES[0];
      const d = 0.12;
      frame.src = `https://www.openstreetmap.org/export/embed.html?bbox=${o.lon - d},${o.lat - d},${o.lon + d},${o.lat + d}&layer=mapnik&marker=${o.lat},${o.lon}`;
      link.href = `https://www.openstreetmap.org/?mlat=${o.lat}&mlon=${o.lon}#map=11/${o.lat}/${o.lon}`;
      info.textContent = `${o.country}: shown on the map is ${o.city}. Local currency: ${o.cur}.`;
      select.value = o.country;
      $$('.chip', btnRow).forEach((b) => { const on = b.textContent === o.country; b.classList.toggle('active', on); b.setAttribute('aria-pressed', String(on)); });
    };
    OFFICES.forEach((o) => {
      const b = el('button', { type: 'button', class: 'chip', 'aria-pressed': 'false', text: o.country });
      b.addEventListener('click', () => go(o.country));
      btnRow.append(b);
    });
    select.addEventListener('change', () => go(select.value));
    const upd = $('.region-form input[type="submit"]');
    if (upd) upd.addEventListener('click', (e) => { e.preventDefault(); go(select.value); });
    go(select.value);
  }

  /* ---------- 4. Form validation ---------- */
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const PHONE = /^\+?[0-9\s()-]{7,16}$/;
  const MAX_FILE = 2 * 1024 * 1024; // 2 MB

  function labelFor(f) {
    let text = '';
    const cell = f.closest('td');
    if (cell && cell.previousElementSibling) text = cell.previousElementSibling.textContent;
    else if (f.type === 'radio') text = 'Please choose an option';
    else {
      const p = f.closest('p');
      if (p && p.querySelector('b')) text = p.querySelector('b').textContent;
      else if (p && p.firstChild && p.firstChild.nodeType === 3 && p.firstChild.textContent.trim()) text = p.firstChild.textContent;
      else if (p && p.previousElementSibling) text = p.previousElementSibling.textContent;
      else if (f.previousElementSibling) text = f.previousElementSibling.textContent;
    }
    return text.replace(/[:?]/g, '').trim() || f.name;
  }

  function checkField(f, form) {
    const name = f.name;
    const label = f.dataset.label;
    if (f.type === 'radio') {
      return $$(`input[name="${name}"]`, form).some((r) => r.checked) ? '' : 'Please choose one option.';
    }
    if (f.type === 'file') {
      const file = f.files && f.files[0];
      if (!file) return `Please choose a file for "${label}".`;
      const ok = f.accept.split(',').some((ext) => file.name.toLowerCase().endsWith(ext.trim()));
      if (f.accept && !ok) return `Wrong file type. Allowed: ${f.accept.replace(/\./g, '').replace(/,/g, ', ')}.`;
      if (file.size > MAX_FILE) return 'File is too large (maximum 2 MB).';
      return '';
    }
    const v = f.value.trim();
    if (!v) return `"${label}" cannot be empty.`;
    if (f.type === 'email' && !EMAIL.test(v)) return 'Enter a valid email address, like name@example.com.';
    if (name === 'phone' && !PHONE.test(v)) return 'Enter a valid phone number (7–16 digits).';
    if (name === 'name' && v.length < 2) return 'Enter at least 2 characters.';
    if (['pickup', 'dropoff', 'address', 'company'].includes(name) && v.length < 3) return 'Enter at least 3 characters.';
    if (name === 'city' && v.length < 2) return 'Enter at least 2 characters.';
    if (name === 'message' && v.length < 10) return 'Please write at least 10 characters.';
    if (name === 'distance') {
      const n = Number(v.replace(',', '.'));
      if (!Number.isFinite(n) || n < 0.5 || n > 500) return 'Enter a distance between 0.5 and 500 km.';
    }
    return '';
  }

  function setError(f, form, msg) {
    const id = f.type === 'radio' ? `err-${f.name}` : `err-${f.id}`;
    let box = document.getElementById(id);
    if (!box) {
      box = el('span', { class: 'field-error', id, role: 'alert' });
      const anchor = f.type === 'radio' ? f.closest('p') : f;
      anchor.insertAdjacentElement('afterend', box);
    }
    box.textContent = msg;
    const targets = f.type === 'radio' ? $$(`input[name="${f.name}"]`, form) : [f];
    targets.forEach((t) => {
      t.classList.toggle('invalid', !!msg);
      t.setAttribute('aria-invalid', String(!!msg));
      t.setAttribute('aria-describedby', id);
    });
  }

  function setupForm(form, index) {
    const fields = $$('input, textarea, select', form).filter((f) => !['submit', 'button', 'hidden'].includes(f.type));
    fields.forEach((f, i) => {
      if (!f.id) f.id = `f${index}-${f.name || i}-${i}`;
      f.dataset.label = labelFor(f);
      if (f.type !== 'radio') f.setAttribute('aria-label', f.dataset.label);
      const run = () => setError(f, form, checkField(f, form));
      f.addEventListener('blur', run);
      f.addEventListener(f.type === 'file' || f.type === 'radio' ? 'change' : 'input', () => {
        if (f.classList.contains('invalid') || f.type === 'file' || f.type === 'radio') run();
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let firstBad = null;
      const seen = new Set();
      fields.forEach((f) => {
        if (f.type === 'radio') { if (seen.has(f.name)) return; seen.add(f.name); }
        const msg = checkField(f, form);
        setError(f, form, msg);
        if (msg && !firstBad) firstBad = f;
      });
      const pu = form.elements.pickup, dr = form.elements.dropoff;
      if (!firstBad && pu && dr && pu.value.trim().toLowerCase() === dr.value.trim().toLowerCase()) {
        setError(dr, form, 'Drop-off must be different from pickup.');
        firstBad = dr;
      }
      if (firstBad) { firstBad.focus(); return; }
      onSuccess(form);
      form.reset();
    });
  }

  function onSuccess(form) {
    const val = (n) => (form.elements[n] ? form.elements[n].value.trim() : '');
    const btn = $('input[type="submit"]', form);
    if (page === 'index') {
      // Hand the trip details to the ride page, which pre-fills its form
      const q = new URLSearchParams({ pickup: val('pickup'), dropoff: val('dropoff') });
      location.href = `ride.html?${q}`;
      return;
    }
    if (page === 'ride') {
      const km = Number(val('distance').replace(',', '.'));
      const rows = RIDES.map((r) => el('li', {}, el('b', { text: r.name + ': ' }), money(r.base + r.perKm * km)));
      showModal('Estimated prices',
        el('p', { text: `${val('pickup')} to ${val('dropoff')} (${km} km)` }),
        el('ul', { class: 'modal-list' }, ...rows),
        el('p', { class: 'note', text: 'Demo estimate using made-up rates. Real prices are shown in the Uber app.' }));
      return;
    }
    if (page === 'deliver') {
      $('#places-title').textContent = `Popular near ${val('address')} (sample listings)`;
      showModal('Search complete', el('p', { text: `Showing sample places for "${val('address')}".` }));
      return;
    }
    const who = val('name') || val('company');
    showModal(who ? `Thank you, ${who}!` : 'Thank you!',
      el('p', { text: `Your form ("${btn ? btn.value : 'Submit'}") passed all checks.` }),
      el('p', { class: 'note', text: 'This is a student project, so nothing is sent or stored.' }));
  }

  $$('form.form-card').forEach(setupForm);

  // Ride page: pre-fill from the home page form (values set via .value, so they stay plain text)
  if (page === 'ride') {
    const params = new URLSearchParams(location.search);
    const f = $('form.form-card');
    if (f && f.elements.pickup && params.get('pickup')) {
      f.elements.pickup.value = params.get('pickup');
      f.elements.dropoff.value = params.get('dropoff') || '';
      if (f.elements.distance) f.elements.distance.focus();
    }
  }
})();
