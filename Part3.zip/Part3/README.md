# Uber Website – Student Project (ST10518638)

A multi-page website for Uber Technologies, Inc., built from the project proposal in `DOCUMENTS/`.

- **Part 1:** HTML structure (11 pages)
- **Part 2:** CSS styling and responsive layout (`style.css`)
- **Part 3:** JavaScript, interactivity, deployment and documentation (`script.js`, this README)

**Live site:** _add your Netlify / GitHub Pages link here after deploying_

## Pages

`index`, `about`, `ride`, `deliver`, `business`, `driver-signup`, `safety`, `help`, `newsroom`, `careers`, `contact`

## Part 3 features

| Requirement | Where it is |
|---|---|
| External JavaScript file linked on every page | `script.js`, loaded with `<script src="script.js" defer>` in all 11 pages |
| DOM manipulation | Service cards (home), ride options (ride), places list (deliver), jobs (careers), stories (news), FAQ (help) and gallery (about) are all built from arrays in `script.js`. Live search bars filter the places, jobs, news and help answers as you type. |
| Form validation | Every form (home, ride, deliver, business, careers, contact, driver sign-up, safety report): empty-field checks, email and phone format, minimum lengths, distance range, file type and size (max 2 MB), radio choice, pickup ≠ drop-off. Errors show under the field with `aria-invalid` and `role="alert"`; the first bad field gets focus. A valid form opens a modal. |
| Interactive elements | FAQ accordion (help), image gallery with lightbox and arrow-key navigation (about), interactive OpenStreetMap with a country selector (contact), category filter chips (deliver) |
| Responsive design | Hamburger menu at 768px and below, fluid grids, 44px touch targets, 2-column gallery on phones, `prefers-reduced-motion` support |
| Deployment | `netlify.toml` and `.nojekyll` included. See "Deployment" below. |
| Documentation | This file |

## Deployment

**Netlify (drag and drop):** sign in at netlify.com → Add new site → Deploy manually → drag the whole `Part2` folder onto the page.

**GitHub Pages:** create a repository, upload the contents of this folder (so `index.html` is at the top level), then Settings → Pages → Deploy from a branch → `main` / root.

After deploying, paste the live URL at the top of this README.

## Testing checklist

1. Open every page and confirm the menu links work.
2. Submit each form empty, then with bad data (e.g. `abc` as an email), then with good data.
3. On mobile width (or browser dev tools), open the menu and check nothing scrolls sideways.
4. Help page: type "card" in the search bar; open and close an answer.
5. About page: open a picture, press the left and right arrow keys, press Esc.
6. Contact page: change the country and check the map and currency text update (needs internet).
7. Navigate the site with the keyboard only (Tab, Enter, Esc).

## Changelog

**v3.0 – Part 3 (JavaScript)**
- Added `script.js` and linked it on all pages.
- Replaced hard-coded cards with content rendered from arrays; added live search on help, careers, news and deliver.
- Added client-side validation with inline error messages and a success modal on all forms.
- Added FAQ accordion, gallery lightbox, interactive map and filter chips.
- Added hamburger navigation for small screens.
- Wrapped all form fields in real `<form>` elements; changed email inputs to `type="email"` and phone to `type="tel"`.
- Accessibility: skip-to-content link, descriptive `alt` text (the old alt text was `width:85;height:75`), visible focus outlines, `aria-current` on the active page, and a darker green (`#047a3f`) for text and hover buttons because the original `#06c167` had a contrast ratio of only 2.4:1 on white (WCAG 2.1 AA needs 4.5:1).
- Added `netlify.toml`, `.nojekyll` and this README.

**v2.0 – Part 2 (CSS)**
- Added `style.css`: reset, colour variables, type scale, card grid, form styling, buttons, tablet and mobile breakpoints.

**v1.0 – Part 1 (HTML)**
- Created the 11 HTML pages and navigation.

## Notes and limitations

- Ride prices use made-up rates and a distance typed in by the user. They are a demo, not real Uber pricing.
- Places on the deliver page are sample listings, not real businesses.
- Forms do not send or store any data; there is no back end.
- Some photos in `IMAGES/` are small and some carry other sites' watermarks (e.g. Getty Images, Investopedia). Replace them, or credit the source, before final submission. The gallery does not use the two watermarked images.

## References (Harvard style)

DCF Modeling (2025) *Uber Technologies, Inc. (UBER): history, ownership, mission, how it works & makes money*. Available at: https://www.dcfmodeling.com/blogs/history/uberhistory-mission-ownership (Accessed: 6 August 2026).

Firewall Times (2023) *Uber mission statement, vision, and values*. Available at: https://firewalltimes.com/uber-mission-statement-vision-values/ (Accessed: 6 August 2026).

MDN Web Docs (n.d.) *\<dialog\>: The Dialog element*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog (Accessed: 2 November 2026).

Netlify (n.d.) *Netlify docs*. Available at: https://docs.netlify.com/ (Accessed: 2 November 2026).

OpenStreetMap contributors (n.d.) *OpenStreetMap*. Available at: https://www.openstreetmap.org/copyright (Accessed: 2 November 2026).

Uber Technologies, Inc. (2026) *About us*. Available at: https://www.uber.com/us/en/about/ (Accessed: 6 August 2026).

W3C (2023) *Web Content Accessibility Guidelines (WCAG) 2.1*. Available at: https://www.w3.org/TR/WCAG21/ (Accessed: 6 August 2026).

W3C Web Accessibility Initiative (n.d.) *Accordion pattern, ARIA Authoring Practices Guide*. Available at: https://www.w3.org/WAI/ARIA/apg/patterns/accordion/ (Accessed: 2 November 2026).

GitHub (n.d.) *GitHub Pages documentation*. Available at: https://docs.github.com/en/pages (Accessed: 2 November 2026).
